library("caTools")
library(RgCop)
library(SingleCellExperiment)
library(Linnorm)
data=as.matrix(read.csv("./pollen_process.csv",header=FALSE))    #should be cells in row, genes in coloumn.
classd<-as.matrix(read.csv("./fsclassd.csv",header=TRUE))


p=15
nf=1000

# Regularized copula based feature selection, the function returns two elements: i) Data with selected features, and ii) The selected feature subset
Result=RgCopfeature(training_set,training_classd, p,nf)
# Data with selected features
Result$Feadata
# The selected feature subset
Result$Features

RgCopfeature <- function(data,classd,p,nf)
{
  library(foreach)
  library(doParallel)
  library('copula')
  library(minerva)
  
  cl <- makeCluster(p)
  registerDoParallel(cl)
  nf=nf
  set.seed(1000)
  datas2<-as.matrix(data)
  classd<-as.matrix(classd)
  n=nrow(datas2)
  col=ncol(datas2)
  count<-1:ncol(datas2)
  start.time <- Sys.time()
  fea=matrix(0, nrow=1,ncol =nf)

  
  # To find relevancy with class
  mimc1<-foreach(j=count, .combine=c,.packages='copula') %dopar%  #Find the most relevant feature
    {
      u=pobs(cbind(classd,datas2[,j]))
      res<-mean(C.n(u, cbind(classd,datas2[,j])))
    }
  mimc1<-as.matrix(mimc1)
  ##########
  x=mimc1
  center <- sweep(x, 2, apply(x, 2, min),'-') 
  R <- apply(x, 2, max) - apply(x,2,min)
  normmimc1<- sweep(center, 2, R, "/")
  ##########
  #############################
  
  miccfp<-foreach(v=count, .combine=rbind,.packages=c("copula", "minerva")) %dopar%
    {
      a=pobs(as.matrix(classd))
      b=pobs(as.matrix(datas2[,v]))
      cc <- cstats(a, b, alpha=0.6, C=15, est="mic_e")
    }
  #miccfp<-as.matrix(miccfp)
  miccf<-as.matrix(miccfp[,3])
  ##############################
  ##########
  x=miccf
  center <- sweep(x, 2, apply(x, 2, min),'-') 
  R <- apply(x, 2, max) - apply(x,2,min)   
  normmiccf<- sweep(center, 2, R, "/")
  ##########
  mimcMICcf<-miccf+mimc1
  normmimc1MICcf<-normmimc1+normmiccf
  datanorm<-cbind(normmimc1,normmiccf)
  ##########
  
  #
  
  first1 <- function(data)
  {
    x <- c(data)
    for(i in 1:length(data))
      x[i] = data[i]/sum(data[])
    return(x)
  }
  dataframe <- apply(datanorm,2,first1)
  #
  
  first2 <- function(data)
  {
    x <- c(data)
    for(i in 1:length(data)){
      if(data[i] == 0){
        x[i] = 0
      }else{
        x[i] = data[i] * log(data[i])
      }
    }
    return(x)
  }
  dataframe1 <- apply(dataframe,2,first2)
  
  k <- 1/log(length(dataframe1[,1]))
  d <- -k * colSums(dataframe1)
  
  #
  d <- 1-d
  
  #
  w <- 1-d/sum(d)
  A=w[1]*normmimc1+w[2]*normmiccf

  # bivariate copula reg
  fea[1,1]<-which.max(mimcMICcf)
  
  
  for (m in 280:nf)
  {
    t1=proc.time()
    print(paste("selected feaure = ", m))
    feas<-fea[1,1:(m-1)]
    
    parl<-foreach(j=count, .combine=c,.packages='copula') %dopar%
      { u1=pobs(cbind(datas2[,feas],datas2[,j]))
      res<-mean(C.n(u1, cbind(datas2[,feas],datas2[,j])))
      }
    red<-as.matrix(parl) 
    
    result<-A-red
    # result<-(mimc1-red) + coeff*(abs(mimc1*varlist))
    result[fea]=Inf
    fea[1,m]<-which.min(result)
    
    t2=proc.time()
    t=t2-t1
    print(paste0('spendtime:',t[3][1],'s'))
  }
  
  stopCluster(cl)
  registerDoSEQ()
  
  
  rgcopdata=data[,fea] # Feature reduced Data with Copula based feature selection
  RgCopresult<- list("Feadata" = rgcopdata, "Features" = fea)
  return(RgCopresult) 
}
