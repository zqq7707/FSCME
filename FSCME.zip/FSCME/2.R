library("caTools")
# load the "pollen_process.csv" and "pollenc.csv" in R file.  
data=as.matrix(read.csv("./muraro_process.csv",header=FALSE))    #should be cells in row, genes in coloumn.
classd<-as.matrix(read.csv("./muraroc.csv",header=FALSE))
p=40
nf=500#nf: Number of feature to be selected


# Regularized copula based feature selection, the function returns two elements: i) Data with selected features, and ii) The selected feature subset
Result=RgCopfeature(data,classd, p,nf)
# Data with selected features
Result$Feadata
# The selected feature subset
Result$Features

