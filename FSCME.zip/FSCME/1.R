library(RgCop)
library(SingleCellExperiment)
library(foreach)
library(doParallel)
library(Linnorm)
library(copula)


Biase_data<- readRDS("./Data/muraro.rds")
data <- assay(Biase_data) 
annotation <- Biase_data[[1]] #already factor type class
colnames(data) <- annotation
data_process = normalized_data(data)
write.table(t(data_process),file="./muraro_process.csv",sep=",",row.names = FALSE,col.names = FALSE)
write.csv(annotation,file="./muraroc.csv")
